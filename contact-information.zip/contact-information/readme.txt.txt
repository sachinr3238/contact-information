The project is implemented using angularJs framework

Folder structure

Root folder (app) 
         |
	Assets - Css - fonts -images - scripts > vendor
	 |
	Components - Contact > contact-controller.js
			     > contact-info.html
	 |
	Shared - As of no empty, if requried we can add service,directive,pipe file in this
	 |
	index.html - Main page which has links/scripts and ng-included file.


To run the app just open the index file.
		OR
http://localhost/contact-information/app/